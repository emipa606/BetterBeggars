# Better Beggars

Better Beggars is a RimWorld mod that enhances the beggars added in the Ideology DLC.
		
This mod allows you to customize how much beggars will ask for, as well as which items they will look for. In addition, it adds two new beggar encounters with more to come in the future!
